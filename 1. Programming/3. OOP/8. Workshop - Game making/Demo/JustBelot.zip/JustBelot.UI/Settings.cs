﻿namespace JustBelot.UI
{
    public static class Settings
    {
        public const string ProgramName = "JustBelot Console 1.0.20130304";

        public const int ConsoleHeight = 20;
    }
}
