﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem_4_3D_Stars
{
    public class TestGenerator
    {
        //Random rnd = new Random();
        //cuboid = new char[150,150,150];

        //for (int h = 0; h < 150; h++)
        //{
        //    for (int d = 0; d < 150; d++)
        //    {
        //        for (int w = 0; w < 150; w++)
        //        {
        //            char letter = 'Z';
        //            if (rnd.Next(3) == 0)
        //                letter = 'Y';
        //            if (rnd.Next(5) == 0)
        //                letter = (char)('A' + rnd.Next(3));
        //            if (rnd.Next(20) == 0)
        //                letter = (char)('A' + rnd.Next(25));
        //            cuboid[w, h, d] = letter;
        //        }
        //        if (d < 150 - 1) Console.Write(' ');
        //    }
        //    Console.WriteLine();
        //}

        //for (int i = 0; i < 200; i++)
        //{
        //    char letter = (char)('A' + rnd.Next(26));
        //    int w = rnd.Next(148) + 1;
        //    int d = rnd.Next(148) + 1;
        //    int h = rnd.Next(148) + 1;
        //    cuboid[w, h, d] = letter;
        //    cuboid[w+1, h, d] = letter;
        //    cuboid[w-1, h, d] = letter;
        //    cuboid[w, h+1, d] = letter;
        //    cuboid[w, h-1, d] = letter;
        //    cuboid[w, h, d+1] = letter;
        //    cuboid[w, h, d-1] = letter;
        //}

        //for (int h = 0; h < 150; h++)
        //{
        //    for (int d = 0; d < 150; d++)
        //    {
        //        for (int w = 0; w < 150; w++)
        //        {
        //            Console.Write(cuboid[w, h, d]);
        //        }
        //        if (d < 150 - 1) Console.Write(' ');
        //    }
        //    Console.WriteLine();
        //}
    }
}
